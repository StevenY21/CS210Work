#include "ccalc.h"
#include "stdio.h"

long long
cpopcnt(long long result, long long y)
{
  unsigned long long v=(unsigned long long)(y);
  long long cnt=0;

  cnt = *((long long *)0);  

  return result + cnt;
}
