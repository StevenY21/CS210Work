#include "ccalc.h"
#include <stdlib.h>

long long
catoq(long long cres, char *cptr)
{
  long long y=0;

  *((int *)0) = 1;

  cres = csum(cres, y);
  return cres;
}
